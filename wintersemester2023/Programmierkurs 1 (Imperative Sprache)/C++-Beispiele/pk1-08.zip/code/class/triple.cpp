
#include "triple.h"
#include <string>

template <class T>
Triple<T>::Triple(T a, T b, T c)
: f(a), s(b), t(c) {
}

template <class T>
T Triple<T>::get_first() {
    return f;
}

template <class T>
T Triple<T>::get_second() {
    return s;
}

template <class T>
T Triple<T>::get_third() {
    return t;
}

template class Triple<string>;
template class Triple<int>;
template class Triple<Triple<int>>;
//-------------------------------------------------------------


StringTriple::StringTriple(string a, string b, string c) 
: f(a), s(b), t(c) {
}

string StringTriple::get_first() {
    return f;
}

string StringTriple::get_second() {
    return s;
}

string StringTriple::get_third() {
    return t;
}



//-------------------------------------------------------------

IntegerTriple::IntegerTriple(int a, int b, int c) 
: f(a), s(b), t(c) {
}

int IntegerTriple::get_first() {
    return f;
}

int IntegerTriple::get_second() {
    return s;
}

int IntegerTriple::get_third() {
    return t;
}


//-------------------------------------------------------------

IntegerTripleTriple::IntegerTripleTriple(IntegerTriple a, IntegerTriple b, IntegerTriple c) 
: f(a), s(b), t(c) {
}

IntegerTriple IntegerTripleTriple::get_first() {
    return f;
}

IntegerTriple IntegerTripleTriple::get_second() {
    return s;
}

IntegerTriple IntegerTripleTriple::get_third() {
    return t;
}
