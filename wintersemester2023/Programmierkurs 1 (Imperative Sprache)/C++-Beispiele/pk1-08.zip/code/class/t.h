
#pragma once

using namespace std;

template<class T>
class Triple {
     public:
        Triple() {}
        Triple(T a, T b, T c);
        
        T get_first();
        T get_second();
        T get_third();
    
    private:    
        T f,s,t;
};

template <class T>
Triple<T>::Triple(T a, T b, T c)
: f(a), s(b), t(c) {
}

template <class T>
T Triple<T>::get_first() {
    return f;
}

template <class T>
T Triple<T>::get_second() {
    return s;
}

template <class T>
T Triple<T>::get_third() {
    return t;
}
