
#pragma once

#include <string>

using namespace std;

template<class T>
class Triple {
     public:
        Triple() {}
        Triple(T a, T b, T c);
        
        T get_first();
        T get_second();
        T get_third();
    
    private:    
        T f,s,t;
};



class StringTriple {

    public:
        StringTriple() {}
        StringTriple(string a, string b, string c);
        
        string get_first();
        string get_second();
        string get_third();
    
    private:    
        string f,s,t;
};

class IntegerTriple {

    public:
        IntegerTriple() {}
        IntegerTriple(int a, int b, int c);
        
        int get_first();
        int get_second();
        int get_third();
    
    private:    
        int f,s,t;
};

class IntegerTripleTriple {

    public:
        IntegerTripleTriple() {}
        IntegerTripleTriple(IntegerTriple a, IntegerTriple b, IntegerTriple c);
        
        IntegerTriple get_first();
        IntegerTriple get_second();
        IntegerTriple get_third();
    
    private:    
        IntegerTriple f,s,t;
};
