

#include<string>
#include<iostream>

#include "t.h"

using namespace std;



int main(void) {
   
   
    Triple<string> traffic_light("red", "yellow", "green");
    cout << traffic_light.get_first() << endl;
    cout << traffic_light.get_second() << endl;
    cout << traffic_light.get_third() << endl;
    
    Triple<int> red(255,0,0);
    cout << red.get_first() << endl;
    
    Triple<Triple<int>> traffic_light2(red,red,red);
    cout << traffic_light2.get_first().get_first() << endl;
}




































/*
    
    Triple<int> red(255,0,0);
    Triple<int> yellow(255,255,0);
    Triple<int> green(0,255,0);
    
    Triple<Triple<int>> traffic_light2(red, yellow, green);
    cout << traffic_light2.get_first().get_first() << endl;
    cout << traffic_light2.get_first().get_second() << endl;
    cout << traffic_light2.get_first().get_third() << endl;

    /*StringTriple traffic_light("red", "yellow", "green");
    
    cout << traffic_light.get_first() << endl;
    cout << traffic_light.get_second() << endl;
    cout << traffic_light.get_third() << endl;
    
    IntegerTriple red(255,0,0);
    IntegerTriple yellow(255,255,0);
    IntegerTriple green(0,255,0);
    
    IntegerTripleTriple traffic_light2(red, yellow, green);
    cout << traffic_light2.get_first().get_first() << endl;
    cout << traffic_light2.get_first().get_second() << endl;
    cout << traffic_light2.get_first().get_third() << endl;*/
    
    

/*
struct Fragezeichen {
    Fragezeichen() {
        cout << "?";
    }
};

Triple<Fragezeichen> tf;
    cout << endl;*/
