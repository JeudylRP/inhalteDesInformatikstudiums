
#include<iostream>

using namespace std;

template<typename T>
T tmax(T x, T y) {
    return (x > y? x : y);
}


int max(int x, int y) {
    return (x > y? x : y);
}

double max(double x, double y) {
    return (x > y? x : y);
}

char max(char x, char y) {
    return (x > y? x : y);
}

 
int main() {

    cout << "\n\nMAX DEMO\n\n";
    
    cout << max(5,8) << endl;
    cout << max(3.142, 2.7) << endl;
    cout << max('h','w') << endl;    
    
        
    cout << tmax(5,8) << endl;
    cout << tmax(3.142, 2.7) << endl;
    cout << tmax('h','w') << endl;    
     
}
