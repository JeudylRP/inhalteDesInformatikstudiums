
#include<iostream>
#include<string>
#include<sstream>
#include<vector>


using namespace std;


template<typename T>
T avg(T x, T y) {
    return ((x+y)/2);
}

template<typename T>
T tmin(T x, T y) {
    return (x < y? x : y);
}


template<typename T, typename U>
string concatenate(T a, U b) {
    stringstream ss;
    ss << a << b;
    return ss.str();
}

template<typename T> 
void print_vector(const vector<T>& v){
    for (int i = 0; i < v.size(); i++)
        cout << v[i] << " ";
    cout << endl;
}

template<typename T, int upto> 
void print_vector(const vector<T>& v){
    int stop = tmin<int>(upto, v.size());
    for (int i = 0; i < stop; i++)
        cout << v[i] << " ";
    cout << endl;
} 

template<typename T> 
void print_vector_prefix(const vector<T>& v, int upto = 5){
    int stop = tmin<int>(upto, v.size());
    for (int i = 0; i < stop; i++)
        cout << v[i] << " ";
    cout << endl;
} 
  
  
int main() {

    cout << "\n\nTEMPLATE FUNCTION DEMO\n\n";

    cout << avg<double>(5,8) << endl;
    cout << avg<int>(5,8) << endl;
    cout << avg(5,8) << endl;
    //cout << avg<string>("hello", "world") << endl;
    cout << endl;
    
    cout << concatenate<string,double>("hello",3.142) << endl;
    cout << concatenate<char,char>('i','t') << endl;
    cout << concatenate<string,string>(concatenate<string,double>("hello",3.142),concatenate<char,char>('i','t')) << endl;
    cout << endl;
    
    srand(time(NULL));
    vector<double> fv;
    for (int i = 0; i < 100; i++)
        fv.push_back((double)rand()/RAND_MAX);
        
    //print_vector<double>(fv);
    //print_vector<double,66>(fv);
    //print_vector<double,5>(fv);
    print_vector_prefix<double>(fv, 7);
}





