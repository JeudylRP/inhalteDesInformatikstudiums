

#include<iostream>

using namespace std;

int main() {

    int a = 2;
    int b = 5;

    cout << a << " " << b << endl;
    
    [&a,&b](){
        a++;
        b++;
    }();
    
    cout << a << " " << b << endl;
    
    [&a](int k){a+=k;}(5);
    cout << a << " " << b << endl;
}

