


#include<iostream>

using namespace std;


int square(int x) {
    return x*x;
}

int just_do_it(int (*fnptr)(int), int x){
    return fnptr(x);
}


int main() {

    cout << square(2) << endl;
    int (*fnptr)(int);
    fnptr = square;
    cout << fnptr(2) << endl;
    cout << just_do_it(square,2) << endl;
    cout << just_do_it([](int x){return x*x*x;},2) << endl;
    
}
