
#include<iostream>
#include<algorithm>
#include<vector>

using namespace std;


template <typename T, typename Function>
void filter(const T& collection, Function f){
    for (const auto& x: collection)
        if (f(x)) cout << x << " ";
    cout << endl;
}

template <typename T>
bool greater_than_five(T x){
    return x > 5;
}

int main() {
    
    int a = 41;
    
    vector<int> v={5,7,3,2,42};
    filter(v,greater_than_five<int>);
    filter(v,[](int x){return x > 5;});
    filter(v,[a](int x){return x > a;});
   
    int numbers[]={3,2,4,1,8}; 
    sort(numbers, numbers+5, [](int x,int y){return x*x > y;});
    for (int i = 0; i < 5; i++)
        cout << numbers[i] << " ";
    cout << endl;
    
    cout << count_if(numbers, numbers+5, [](int x){return x%4==0;}) << endl;
}
