
#include<iostream>

using namespace std;

int main() {

    auto lambda = [](){cout << "half-life 3 confirmed" << endl;};
    lambda();
    lambda();
    
    auto sum = [](int x, int y) {return x+y;};
    cout << sum(6,7) << endl;

}
