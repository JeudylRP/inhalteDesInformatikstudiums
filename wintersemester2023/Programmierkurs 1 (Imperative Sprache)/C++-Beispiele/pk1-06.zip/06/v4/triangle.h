#pragma once

#include "shape.h"

class Triangle : public Shape {
 private:
  XYPoint p1_, p2_, p3_;
 public:
  Triangle(XYPoint p1, XYPoint p2, XYPoint p3);
  ~Triangle() override = default;
  double area() override;
};
