#include <cstdlib>
#include <iostream>
#include <vector>
#include "shape.h"
#include "triangle.h"

int main(void) {
  std::vector<Shape*> shapes;

  Circle circle({8, 4}, 3);
  shapes.push_back(&circle);

  Rectangle rectangle({1, 11}, 8, 3);
  shapes.push_back(&rectangle);

  Triangle triangle({0, 3}, {0, 0}, {3, 0});
  shapes.push_back(&triangle);

  for (Shape* s : shapes) {
    std::cout << s->area() << std::endl;
  }

  return EXIT_SUCCESS;
}
