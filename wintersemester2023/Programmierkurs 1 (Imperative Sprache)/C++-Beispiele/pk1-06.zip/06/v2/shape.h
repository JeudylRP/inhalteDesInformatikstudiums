#pragma once

enum class Type { circle, rectangle };

struct XYPoint {
  int x;
  int y;
};

double distance(XYPoint p1, XYPoint p2);

class Shape {
 private:
  Type type_;
  XYPoint points_[2];
 public:
  Shape(Type type, XYPoint p1, XYPoint p2);
  double area();
};
