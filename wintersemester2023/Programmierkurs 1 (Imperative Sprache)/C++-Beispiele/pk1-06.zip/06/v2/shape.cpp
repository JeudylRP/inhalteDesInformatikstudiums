#include "shape.h"
#include <cmath>

double distance(XYPoint p1, XYPoint p2) {
  return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}


Shape::Shape(Type type, XYPoint p1, XYPoint p2)
    : type_{type}, points_{p1, p2} {}

double Shape::area() {
  switch (this->type_) {
  case Type::circle:
    return M_PI * (pow(points_[0].x - points_[1].x, 2) +
                   pow(points_[0].y - points_[1].y, 2));
  case Type::rectangle:
    return abs(points_[0].x - points_[1].x) * abs(points_[0].y - points_[1].y);
  default:
    return NAN;
  }
}
