#include <cstdlib>
#include <iostream>
#include <vector>
#include "shape.h"

int main(void) {
  std::vector<Shape*> shapes;

  // For a circle, we specify the center point and its radius.
  Circle circle({8, 4}, 3);
  shapes.push_back(&circle);

  // For a rectangle, we specify the upper-left corner, width, and height.
  Rectangle rectangle({1, 11}, 8, 3);
  shapes.push_back(&rectangle);

  for (Shape* s : shapes) {
    std::cout << s->area() << std::endl;
  }
  return EXIT_SUCCESS;
}
