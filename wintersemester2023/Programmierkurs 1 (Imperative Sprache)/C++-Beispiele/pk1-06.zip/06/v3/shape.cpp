#include "shape.h"
#include <cmath>

double distance(XYPoint p1, XYPoint p2) {
  return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}


double Shape::area() {
      return NAN;
}


Circle::Circle(XYPoint center, int radius)
    : center_(center), radius_(radius) {
}

double Circle::area() {
  return M_PI * radius_ * radius_;
}


Rectangle::Rectangle(XYPoint upleft, int width, int height)
    : upleft_(upleft), width_(width), height_(height) {
}

double Rectangle::area() {
  return width_ * height_;
}
