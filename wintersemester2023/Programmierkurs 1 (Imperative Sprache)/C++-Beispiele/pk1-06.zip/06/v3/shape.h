#pragma once

struct XYPoint {
  int x;
  int y;
};

double distance(XYPoint p1, XYPoint p2);

class Shape {
 public:
  double area();
};

class Circle : public Shape {
 private:
  XYPoint center_;
  int radius_;
 public:
  Circle(XYPoint center, int radius);
  double area();
};

class Rectangle : public Shape {
 private:
  XYPoint upleft_;
  int width_;
  int height_;
 public:
  Rectangle(XYPoint upleft, int width, int height);
  double area();
};
