#pragma once

enum class Type { circle, rectangle };

struct XYPoint {
  int x;
  int y;
};

double distance(XYPoint p1, XYPoint p2);

struct Shape {
  Type type;
  XYPoint points[2];
};

double area(const Shape* shape);
