#include <cstdlib>
#include <iostream>
#include <vector>
#include "shape.h"

int main(void) {
  std::vector<Shape*> shapes;

  // For a circle, we specify the center and a point on the circumference.
  Shape circle({Type::circle, {{8, 4}, {11, 4}}});
  shapes.push_back(&circle);

  // For a rectangle, we specify the upper-left and the lower-right corner.
  Shape rectangle({Type::rectangle, {{1, 11}, {9, 8}}});
  shapes.push_back(&rectangle);

  for (Shape* s : shapes) {
    std::cout << area(s) << std::endl;
  }
  return EXIT_SUCCESS;
}
