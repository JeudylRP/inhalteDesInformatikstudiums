#include "shape.h"
#include <cmath>

double distance(XYPoint p1, XYPoint p2) {
  return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}

double area(const Shape* shape) {
  switch (shape->type) {
  case Type::circle:
    return M_PI * (pow(shape->points[0].x - shape->points[1].x, 2) +
                   pow(shape->points[0].y - shape->points[1].y, 2));
  case Type::rectangle:
    return abs(shape->points[0].x - shape->points[1].x) *
           abs(shape->points[0].y - shape->points[1].y);
  default:
    return NAN;
  }
}
