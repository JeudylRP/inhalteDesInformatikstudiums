#include <iostream>

using namespace std;

int rfactorial(int n) {
  if (n == 1) {
    return 1;
  }
  return n * rfactorial(n - 1);
}

int ifactorial(int n) {
  int res = n;
  for (int i = n - 1; i > 0; i--) {
    res*= i;
  }
  return res;
}


int main(int argc, char* argv[]) {
  if (argc < 2) {
    return EXIT_FAILURE;
  }
  cout << rfactorial(atoi(argv[1])) << endl;
  return EXIT_SUCCESS;
}
