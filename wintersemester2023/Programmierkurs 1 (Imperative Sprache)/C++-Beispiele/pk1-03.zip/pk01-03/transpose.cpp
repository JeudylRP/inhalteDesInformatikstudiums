#include<fstream>
#include<iostream>
#include<string>
#include<vector>

using namespace std;

int main(int argc, char* argv[]) {
	if (argc < 3) {
		cerr << "Dieses Programm benötigt mindestens zwei Argumente." << endl;
		return EXIT_FAILURE;
	}
	ifstream ifile(argv[1]);
	vector<vector<int>> matrix;
	int a, b, c;
	while (ifile >> a >> b >> c) {
		matrix.push_back(vector<int>({ a, b, c }));
	}
	ifile.close();
	ofstream ofile(argv[2]);
	for (int j = 0; j < 3; j++) {
		for (int i = 0; i < 3; i++) {
		  ofile << matrix[i][j] << " ";
		}
		ofile << endl;
	}
	ofile.close();
	return EXIT_SUCCESS;
}