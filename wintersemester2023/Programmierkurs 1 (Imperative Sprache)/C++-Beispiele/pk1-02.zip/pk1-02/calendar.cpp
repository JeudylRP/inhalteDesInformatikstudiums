#include <iostream>

using namespace std;

int zeller(int tag, int monat, int jahr) {
  if (monat < 3) {
    monat += 12;
    jahr--;
  }
  int jh = jahr / 100;
  int jz = jahr % 100;
  int h = (tag + (((monat + 1) * 13) / 5) + jz + (jz / 4) + (jh / 4) - 2 * jh) % 7;
  return h;
}

int main(int argc, char* argv[]) {
  if (argc < 4) {
    cout << "Mehr Argumente!!!" << endl;
    return EXIT_FAILURE;
  }
  auto tag = atoi(argv[1]);
  auto monat = atoi(argv[2]);
  auto jahr = atoi(argv[3]);

  auto index = zeller(tag, monat, jahr);

  string name;
  switch (index) {
    case 0: name = "Samstag"; break;
    case 1: name = "Sonntag"; break;
    case 2: name = "Montag"; break;
    case 3: name = "Dienstag"; break;
    case 4: name = "Mittwoch"; break;
    case 5: name = "Donnerstag"; break;
    case 6: name = "Freitag"; break;
  }
  cout << name << endl;
  return EXIT_SUCCESS;
}
