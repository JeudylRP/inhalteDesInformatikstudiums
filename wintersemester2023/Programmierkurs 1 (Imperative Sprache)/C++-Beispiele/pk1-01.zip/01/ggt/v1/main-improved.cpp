#include <cassert>
#include <iostream>

unsigned int ggT(unsigned int a, unsigned int b) {
  if (a < b) {
    return ggT(b, a);
  }
  assert(a >= b);
  return b == 0 ? a : ggT(b, a % b);
}

int main(int argc, char* argv[]) {
  if (argc < 3) {
    std::cerr << "Dieses Programm benötigt mindestens zwei Argumente." << std::endl;
    return EXIT_FAILURE;
  }
  std::cout << ggT(atoi(argv[1]), atoi(argv[2])) << std::endl;
  return EXIT_SUCCESS;
}
