#include <cassert>
#include <iostream>

unsigned int ggT(unsigned int a, unsigned int b) {
  assert(a >= b);
  int t;
  if (b == 0) {
    t = a;
  } else {
    t = ggT(b, a % b);
  }
  return t;
}

int main() {
  std::cout << ggT(123, 27) << std::endl;
  return 0;
}
