#include <cassert>
#include <utility>

unsigned int ggT(unsigned int a, unsigned int b) {
  if (a < b) {
    return ggT(b, a);
  }
  assert(a >= b);
  if (b == 0) {
    return a;
  }
  return ggT(b, a % b);
}
