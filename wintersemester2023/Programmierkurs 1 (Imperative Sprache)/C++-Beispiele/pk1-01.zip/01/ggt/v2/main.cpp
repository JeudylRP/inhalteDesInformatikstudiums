#include "./ggt.cpp"
#include <iostream>

int main(int argc, char* argv[]) {
  if (argc <= 2) {
    std::cerr << "Dieses Programm benötigt mindestens zwei Argumente." << std::endl;
    return EXIT_FAILURE;
  }
  std::cout << ggT(atoi(argv[1]), atoi(argv[2])) << std::endl;
  return EXIT_SUCCESS;
}
