#include <cassert>
#include <utility>

int ggT(int a, int b) {
  if (a < b) {
    std::swap(a, b);
  }
  assert(a >= b);
  if (b == 0) {
    return a;
  }
  return ggT(b, a % b);
}
