#include <gtest/gtest.h>
#include "./ggt.cpp"

TEST(GGTSuite, checkGGT) {
  EXPECT_EQ(3, ggT(123, 27)) << "Das Ergebnis von ggT(123, 27) sollte 3 sein.";
}

int main() {
  ::testing::InitGoogleTest();
  return RUN_ALL_TESTS();
}

