#include <iostream>

using std::cout;
using std::endl;
using std::ostream;

// Datentyp eines Listenelements
// `val`:  int-Wert des Listenelements
// `next`: Zeiger auf das nächste Listenelement
struct Elem {
  int val;
  Elem* next;
};

// Datentyp der verketteten Liste
// `first`: Zeiger auf das erste Listenelement
// `last`:  Zeiger auf das letzte Listenelement
struct List {
  Elem* first;
  Elem* last;
};

// Funktion zum Erstellen einer neuen, leeren verketteten Liste
List* create() {
  // Dymanmisches Erstellen eines neuen Wert vom Typ List
  auto l = new List;
  // Initialisierung von `first` und `last` mit `nullptr`, damit später
  // überprüft werden kann, ob die Liste leer ist
  l->first = nullptr;
  l->last = l->first;
  // Rückgabe der neuen, leeren Liste `l`
  return l;
}

// Funktion zum Einfügen eines Wertes `val` in die verkettete Liste `l`
// `l`:   verkettete Liste, an die angehängt werden soll
// `val`: der Wert, der angehängt werden soll
void append(List* l, int val) {
  // Dynamisches Erstellen eines neuen Listenelements
  auto elem = new Elem;
  // Setze den Wert des Listenelements auf val
  elem->val = val;
  // Das neue Listenelement wird hinten an die Liste angehängt:
  // der Zeiger auf das nächste Element wird daher mit
  // `nullptr` initialisiert
  elem->next = nullptr;
  // Überprüfen, ob die übergebene Liste leer ist
  if (!l->first) {
    // Leere Liste: das neue Element wird als erstes Element
    // eingefügt
    l->first = elem;
  } else {
    // Nichtleere Liste: das neue Element wird ans letzte Element
    // angehängt
    l->last->next = elem;
  }
  // Das neue Element ist das neue letzte Element der Liste
  l->last = elem;
}

// Funktion zum Löschen eines Wertes `val` aus der verkettete Liste `l`
// `l`:   verkettete Liste, aus der gelöscht werden soll
// `val`: der Wert, der gelöscht werden soll
void remove(List* l, int val) {
  // Falls es ein Listenelement mit dem Wert `val` gibt, zeigt der
  // Zeiger `elem` auf dieses Element
  Elem* elem = nullptr;
  // Um Element löschen (durch überspringen) zu können, brauchen
  // wir den Zeiger `previous` auf das Vorgängerelement
  Elem* previous;
  // Der Zeiger `current` ist unsere Schleifenvariable
  auto current = l->first;
  // Wir iterieren, solange `current` nicht `nullptr` ist
  // Die Abbruchbedingung ist kurz für `current != nullptr`
  while (current) {
    // Prüfen, ob das Element mit dem gesuchten Wert `val` gefunden
    // wurde
    if (val == current->val) {
      // Wir merken uns das gefundene Element in `elem`
      elem = current;
      // Schleife abbrechen, da Element gefunden
      break;
    }
    // Vorgängerelement in `previous` merken
    previous = current;
    // Schleifenvariable um ein Element weiterbewegen
    current = current->next;
  }
  // Prüfen, ob das gesuchte Element in der Liste gefunden wurde
  if (elem) {
    if (elem == l->first) {
      // Falls das gefundene Element das erste Element ist (bzw. falls
      // der Zeiger auf das gefundene Element `elem` an die gleiche
      // Adresse zeigt, wie der Zeiger auf das erste Listenelement
      // `l->first`), kann das Element gelöscht werden, indem der Zeiger
      // auf das erste Listenelement auf den Nachfolger des gefundenen
      // Elemenent gesetzt wird
      l->first = elem->next;
    } else {
      // Im allgemeinen Fall überspringen wir das Element, indem wir den
      // `next`-Zeiger im Vorgänger auf den Nachfolger des Elements
      // gesetzt, das wir löschen wollen
      previous->next = elem->next;
      // Falls wir gerade das letzte Element löschen, müssen der Zeiger
      // der Liste auf das letzte Element (`l->last`) auf den Vorgänger
      // gestetzt wird
      if (elem == l->last) {
        l->last = previous;
      }
    }
    // Freigabe des Speicherbereichs des zu löschenden Elements
    delete elem;
  }
}

// Funktion zur Ausgabe aller Listenelement auf den gebenen Output-Stream
// `l`:  Liste die ausgegeben werden soll
// `os`: Output-Stream, auf den geschrieben werden soll
void print(List* l, ostream &os) {
  // Der Zeiger `current` ist unsere Schleifenvariable
  auto current = l->first;
  // Wir iterieren, solange `current` nicht `nullptr` ist
  // Die Abbruchbedingung ist kurz für `current != nullptr`
  while (current) {
    // Ausgabe des Werts, der im aktuellen Listenelement gespeichert ist
    os << current->val << " ";
    // Schleifenvariable um ein Element weiterbewegen
    current = current->next;
  }
  // Ausgabe eines Zeilenumbruchs am Ende der Liste
  os << endl;
}

// Funktion zum Löschen einer verketteten Liste
// `l`: die zu löschende Liste
void destroy(List* l) {
  // Der Zeiger `current` ist unsere Schleifenvariable
  auto current = l->first;
  // Wir iterieren, solange `current` nicht `nullptr` ist
  // Die Abbruchbedingung ist kurz für `current != nullptr`
  while (current) {
    // Wir merken uns das Element, das gelöscht werden soll
    auto previous = current;
    // Schleifenvariable um ein Element weiterbewegen
    current = current->next;
    // Freigabe des Speicherbereichs des zu löschenden Elements
    delete previous;
  }
  // Freigabe des Speicherbereichs der zu löschenden Liste
  delete l;
}


int main() {
  // Erstelle eine neue, leere verkettete Liste
  auto list = create();
  // Füge die Zahlen 0..9 in die Liste ein
  for (int i = 0; i < 10; i++) {
    append(list, i);
  }
  // Ausgabe der Liste: 0 1 2 3 4 5 6 7 8 9
  print(list, cout);
  // Lösche das erste Element (Spezialfall wegen `l->first`)
  remove(list, 0);
  // Lösche ein allgemeines Element (Regelfall)
  remove(list, 5);
  // Lösche das letzte Element (Spezialfall wegen `l->last`)
  remove(list, 9);
  // Ausgabe der Liste: 1 2 3 4 6 7 8
  print(list, cout);
  // Lösche die gesamte Liste
  destroy(list);
  return EXIT_SUCCESS;
}
