#pragma once

// Berechnet den größten gemeinsamen Teiler der Zahlen `a` und `b`
unsigned int ggT(unsigned int a, unsigned int b);
