#include "ggt.h"

unsigned int ggT(unsigned int a, unsigned int b) {
  if (a < b) {
    return ggT(b, a);
  }
  return b == 0 ? a : ggT(b, a % b);
}
