#include <gtest/gtest.h>
#include "./ggt.h"

TEST(GGTSuite, checkGGT) {
  EXPECT_EQ(3, ggT(123, 27)) << "Das Ergebnis von ggT(123, 27) sollte 3 sein.";
  EXPECT_EQ(3, ggT(27, 123)) << "Das Ergebnis von ggT(27, 123) sollte 3 sein.";
}

int main() {
  ::testing::InitGoogleTest();
  return RUN_ALL_TESTS();
}

