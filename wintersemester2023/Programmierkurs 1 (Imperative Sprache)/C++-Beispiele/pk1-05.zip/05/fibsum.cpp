#include <cstdlib>
#include <iostream>
#include <vector>

using std::endl;
using std::cerr;
using std::cout;
using std::vector;

void fibonacci(vector<int>& v, int n) {
  for (int i = 0; i < n; i++) {
    if (i < 2) {
      v.push_back(1);
    } else  {
      v.push_back(v[i-1] + v[i-2]);
    }
  }
}

int sum(const vector<int>& v) {
  int res = 0;
  for (int i : v) {
    res += i;
  }
  return res;
}

int main(int argc, char* argv[]) {
  if (argc < 2) {
    cerr << "Dieses Programm benötigt mindestens ein Argument." << endl;
    return EXIT_FAILURE;
  }
  vector<int> v;
  fibonacci(v, atoi(argv[1]));
  cout << sum(v) << endl;
  return EXIT_SUCCESS;
}
