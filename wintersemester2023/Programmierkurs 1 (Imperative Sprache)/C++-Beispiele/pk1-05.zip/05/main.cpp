#include <cstdlib>
#include <iostream>
#include "ggt.h"

using std::cerr;
using std::cout;
using std::endl;

int main(int argc, char* argv[]) {
  if (argc <= 2) {
    cerr << "Dieses Programm benötigt mindestens zwei Argumente!" << endl;
    return EXIT_FAILURE;
  }
  cout << ggT(atoi(argv[1]), atoi(argv[2])) << endl;
  return EXIT_SUCCESS;
}
