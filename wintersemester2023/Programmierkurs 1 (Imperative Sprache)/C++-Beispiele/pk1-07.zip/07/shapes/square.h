#pragma once

#include "shape.h"

class Square final : public Rectangle {
 public:
  Square(XYPoint upleft, int side) :
    Rectangle(upleft, side, side) { }
};
