#include "triangle.h"
#include <cmath>

Triangle::Triangle(XYPoint p1, XYPoint p2, XYPoint p3)
    : p1_(p1), p2_(p2), p3_(p3) {
}

double Triangle::area() {
  double a = distance(p1_, p2_);
  double b = distance(p2_, p3_);
  double c = distance(p3_, p1_);
  double s = (a + b + c) / 2;
  return sqrt(s * (s - a) * (s - b) * (s - c));
}
