#pragma once

#include <iostream>

using std::ostream;

class Collection {
 public:
  virtual ~Collection() = default;
  virtual void add(int val) = 0;
  virtual bool contains(int val) const = 0;
  virtual void remove(int val) = 0;
  virtual bool empty() const { return size() == 0; }
  virtual int size() const = 0;
  virtual void print(ostream& os) const = 0;
};
