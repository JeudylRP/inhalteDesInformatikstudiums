#include <memory>
#include <utility>
#include "LinkedList.h"

using std::endl;
using std::make_unique;
using std::move;
using std::ostream;

LinkedList::~LinkedList() {
  this->clear();
}

LinkedList::LinkedList(const LinkedList& rhs) : first_(), last_(), size_() {
  this->add(rhs);
}

LinkedList& LinkedList::operator=(const LinkedList& rhs) {
  if (this != &rhs) {
    this->clear();
    this->add(rhs);
  }
  return *this;
}

LinkedList::LinkedList(LinkedList&& rhs) : first_(), last_(), size_() {
  this->first_ = move(rhs.first_);
  this->last_ = rhs.last_;
  rhs.last_ = nullptr;
  this->size_ = rhs.size_;
  rhs.size_ = 0;
}

LinkedList& LinkedList::operator=(LinkedList&& rhs) {
  this->clear();
  this->first_ = move(rhs.first_);
  this->last_ = rhs.last_;
  rhs.last_ = nullptr;
  this->size_ = rhs.size_;
  rhs.size_ = 0;
  return *this;
}

LinkedList LinkedList::operator+(const LinkedList& rhs) {
  LinkedList res = *this;
  res += rhs;
  return res;
}

LinkedList& LinkedList::operator+=(const LinkedList& rhs) {
  this->add(rhs);
  return *this;
}

LinkedList& LinkedList::operator+=(LinkedList&& rhs) {
  if (this->first_) {
    this->last_->next = move(rhs.first_);
    this->last_ = rhs.last_;
    rhs.last_ = nullptr;
    this->size_ += rhs.size_;
    rhs.size_ = 0;
  } else {
    *this = move(rhs);
  }
  return *this;
}

void LinkedList::add(const LinkedList& list) {
  auto current = list.first_.get();
  while (current) {
    this->add(current->val);
    current = current->next.get();
  }
}

void LinkedList::clear() {
  auto current = move(first_);
  while (current) {
    current = move(current->next);
  }
  first_ = nullptr;
  last_ = nullptr;
  size_ = 0;
}

void LinkedList::add(int val) {
  auto elem = make_unique<Elem>();
  elem->val = val;
  elem->next = nullptr;
  if (!first_) {
    first_ = move(elem);
    last_ = first_.get();
  } else {
    last_->next = move(elem);
    last_ = last_->next.get();
  }
  size_++;
}

bool LinkedList::contains(int val) const {
  auto current = first_.get();
  while (current) {
    if (val == current->val) {
      return true;
    }
  }
  return false;
}

void LinkedList::remove(int val) {
  Elem* elem = nullptr;
  Elem* previous = nullptr;
  auto current = first_.get();
  while (current) {
    if (val == current->val) {
      elem = current;
      break;
    }
    previous = current;
    current = current->next.get();
  }
  if (elem) {
    if (elem == first_.get()) {
      first_ = std::move(elem->next);
    } else {
      previous->next = std::move(elem->next);
      if (elem == last_) {
        last_ = previous;
      }
    }
    size_--;
  }
}

int LinkedList::size() const {
  return size_;
}

void LinkedList::print(ostream& os) const {
  auto current = first_.get();
  os << "[";
  while (current) {
    os << current->val;
    current = current->next.get();
    if (current) {
      os << ",";
    }
  }
  os << "]";
}
