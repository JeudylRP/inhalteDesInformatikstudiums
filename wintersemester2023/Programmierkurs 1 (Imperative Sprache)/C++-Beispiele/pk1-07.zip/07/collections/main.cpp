#include <iostream>
#include <string>
#include "LinkedList.h"

using std::cout;
using std::endl;
using std::move;
using std::ostream;
using std::string;

void print(string name, const LinkedList& list) {
  cout << name << "<" << list.size() << "> ";
  list.print(cout);
  cout << endl;
}

int main(void) {
  // Default-Konstruktor
  LinkedList xs;
  for (int i = 0; i < 10; i++) {
    xs.add(i);
  }
  for (int i = 0; i < 10; i++) {
    xs.remove(9 - i);
  }
  // Gibt die leere Liste [] aus
  print("xs", xs);
  for (int i = 0; i < 10; i++) {
    xs.add(i);
  }
  // Gibt die Liste [0,1,2,3,4,5,6,7,8,9] aus
  print("xs", xs);
  xs.remove(0);
  xs.remove(5);
  xs.remove(9);
  // Gibt die Liste [1,2,3,4,6,7,8] aus
  print("xs", xs);
  // Copy-Konstruktor
  LinkedList ys = xs;
  ys.add(9);
  ys.add(10);
  print("xs", xs);
  print("ys", ys);
  // Copy-Zuweisungsoperator
  xs = ys;
  print("xs", xs);
  print("ys", ys);
  // operator+
  LinkedList zs = xs + ys;
  print("zs", zs);
  // operator+=
  xs += ys;
  print("xs", xs);
  // Move-Zuweisungsoperator
  zs = move(ys);
  print("zs", zs);
  print("ys", ys);
  xs += move(zs);
  print("zs", zs);
  print("xs", xs);
  return EXIT_SUCCESS;
}
