#pragma once

#include <iostream>
#include <memory>
#include "Collection.h"

using std::ostream;
using std::unique_ptr;

class LinkedList : public Collection {
  struct Elem {
    int val;
    unique_ptr<Elem> next;
  };
  unique_ptr<Elem> first_;
  Elem *last_;
  int size_;
  void add(const LinkedList& list);
  void clear();

 public:
  // Default Constructor
  LinkedList() : first_(), last_(), size_() { }

  // Copy Constructor
  LinkedList(const LinkedList& rhs);
  // Move Constructor
  LinkedList(LinkedList&& rhs);

  // Destructor
  ~LinkedList() override;

  void add(int val) override;
  bool contains(int val) const override;
  void remove(int val) override;
  int size() const override;
  void print(ostream& os) const override;

  // Copy Assignement Operator
  LinkedList& operator=(const LinkedList& rhs);
  // Move Assignement Operator
  LinkedList& operator=(LinkedList&& rhs);

  LinkedList operator+(const LinkedList& rhs);
  LinkedList& operator+=(const LinkedList& rhs);
  LinkedList& operator+=(LinkedList&& rhs);
};
